# CCAPDEV_Forum
Web Forum Application for CCAPDEV MCO

to run the web forum application, run these in your terminal:

npm i

node app